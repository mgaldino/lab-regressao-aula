import fs from "node:fs/promises";
import path from "node:path";
import { Presentation, PresentationFile } from "@oai/artifact-tool";

const ROOT = process.cwd();
const OUT_DIR = path.join(ROOT, "materials_aula_02");
const PREVIEW_DIR = path.join(OUT_DIR, "rendered");
const PPTX_PATH = path.join(OUT_DIR, "aula_02_teoria_distribuicoes.pptx");
const MONTAGE_PATH = path.join(OUT_DIR, "rendered", "montage.webp");

const W = 1280;
const H = 720;
const FONT = "Helvetica Neue";
const C = {
  canvas: "#FFFFFF",
  ink: "#000000",
  muted: "#505761",
  panel: "#EDEDED",
  panel2: "#F6F7F8",
  rule: "#B8BCC4",
  accent: "#6DCBF4",
  accentStrong: "#3D8DFF",
  accentPale: "#D0EDFA",
  warning: "#F5A623",
};

const CAMBRIDGE = "https://www.cambridge.org/core/books/abs/foundations-of-agnostic-statistics/summarizing-distributions/16F75B68EABD0738A8B11BFFA9E312C0";
const DOI = "https://doi.org/10.1017/9781316831762.003";
const SYLLABUS = "inputs/syllabus_2026_updated.Rmd";

function addBox(slide, name, left, top, width, height, fill = C.panel2, line = C.rule, radius = false) {
  return slide.shapes.add({
    geometry: radius ? "roundRect" : "rect",
    name,
    position: { left, top, width, height },
    fill,
    line: { style: "solid", fill: line, width: line === "none" ? 0 : 1 },
    ...(radius ? { borderRadius: "rounded-lg" } : {}),
  });
}

function addText(slide, name, text, left, top, width, height, opts = {}) {
  const shape = slide.shapes.add({
    geometry: "textbox",
    name,
    position: { left, top, width, height },
    fill: opts.fill ?? "none",
    line: { style: "solid", fill: "none", width: 0 },
  });
  if (Array.isArray(text) || typeof text === "object") shape.text.set(text);
  else shape.text = text;
  shape.text.style = {
    fontSize: opts.fontSize ?? 24,
    bold: opts.bold ?? false,
    italic: opts.italic ?? false,
    color: opts.color ?? C.ink,
    alignment: opts.alignment ?? "left",
    verticalAlignment: opts.verticalAlignment ?? "top",
    autoFit: opts.autoFit ?? "none",
    wrap: "square",
    typeface: FONT,
    lineSpacing: opts.lineSpacing ?? 1.0,
    insets: opts.insets ?? { top: 0, right: 0, bottom: 0, left: 0 },
  };
  return shape;
}

function addBullets(slide, name, items, left, top, width, height, opts = {}) {
  const paragraphs = items.map((item) => ({
    bulletCharacter: opts.bulletCharacter ?? "•",
    marginLeft: opts.marginLeft ?? 26,
    indent: opts.indent ?? -14,
    spaceAfter: opts.spaceAfter ?? 11,
    runs: Array.isArray(item) ? item : [item],
  }));
  return addText(slide, name, paragraphs, left, top, width, height, {
    fontSize: opts.fontSize ?? 24,
    color: opts.color ?? C.ink,
    lineSpacing: opts.lineSpacing ?? 1.03,
  });
}

function addRule(slide, left, top, width, color = C.rule, height = 1) {
  addBox(slide, `rule-${left}-${top}`, left, top, width, height, color, "none");
}

function addHeader(slide, number, title, eyebrow = "AULA 2 · RESUMINDO DISTRIBUIÇÕES") {
  addText(slide, `eyebrow-${number}`, eyebrow, 48, 28, 700, 24, {
    fontSize: 16,
    bold: true,
    color: C.muted,
  });
  addText(slide, `title-${number}`, title, 48, 58, 1184, 74, {
    fontSize: 48,
    bold: true,
  });
  addRule(slide, 48, 142, 1184, C.ink, 2);
}

function addFooter(slide, number) {
  addRule(slide, 48, 674, 1184, C.rule, 1);
  addText(slide, `footer-course-${number}`, "FLS 6183 · Métodos Quantitativos de Pesquisa II", 48, 682, 600, 20, {
    fontSize: 15,
    color: C.muted,
  });
  addText(slide, `footer-number-${number}`, String(number).padStart(2, "0"), 1170, 682, 62, 20, {
    fontSize: 15,
    bold: true,
    alignment: "right",
    color: C.muted,
  });
}

function addCaption(slide, figureNumber, caption, left, top, width) {
  addText(slide, `caption-${figureNumber}`, `Figura ${figureNumber}. ${caption}`, left, top, width, 30, {
    fontSize: 17,
    color: C.muted,
    italic: true,
  });
}

function addNotes(slide, talkTrack, sources) {
  const sourceLines = sources.map((s) => `- ${s}`).join("\n");
  slide.speakerNotes.textFrame.setText(
    `${talkTrack}\n\n[Sources]\n${sourceLines}`,
  );
  slide.speakerNotes.setVisible(true);
}

function newSlide(presentation) {
  const slide = presentation.slides.add();
  slide.background.fill = C.canvas;
  return slide;
}

function addStandardFrame(slide, number, title, eyebrow) {
  addHeader(slide, number, title, eyebrow);
  addFooter(slide, number);
}

function addCallout(slide, name, value, label, left, top, width, height, fill = C.panel) {
  addBox(slide, `${name}-box`, left, top, width, height, fill, "none");
  addText(slide, `${name}-value`, value, left + 22, top + 20, width - 44, 58, {
    fontSize: 42,
    bold: true,
    color: C.accentStrong,
  });
  addText(slide, `${name}-label`, label, left + 22, top + 84, width - 44, height - 98, {
    fontSize: 21,
    color: C.ink,
  });
}

async function writeBlob(filePath, blob) {
  await fs.writeFile(filePath, new Uint8Array(await blob.arrayBuffer()));
}

async function buildDeck() {
  await fs.mkdir(OUT_DIR, { recursive: true });
  await fs.mkdir(PREVIEW_DIR, { recursive: true });

  const presentation = Presentation.create({ slideSize: { width: W, height: H } });

  // 1. Capa — Codex Grid, capa esparsa.
  {
    const slide = newSlide(presentation);
    addText(slide, "cover-eyebrow", "FLS 6183 · AULA 2 · 26/08/2026", 48, 38, 720, 28, {
      fontSize: 19,
      bold: true,
      color: C.muted,
    });
    addText(slide, "cover-course", "Métodos Quantitativos de Pesquisa II", 850, 38, 382, 28, {
      fontSize: 19,
      alignment: "right",
      color: C.muted,
    });
    addText(slide, "cover-title", "Resumindo\ndistribuições", 48, 246, 850, 190, {
      fontSize: 80,
      bold: true,
      lineSpacing: 0.9,
      verticalAlignment: "bottom",
    });
    addText(slide, "cover-subtitle", "Esperança · momentos · variância · MSE · covariância · correlação", 48, 468, 1060, 44, {
      fontSize: 27,
      color: C.muted,
    });
    addBox(slide, "cover-accent", 48, 548, 420, 10, C.accentStrong, "none");
    addText(slide, "cover-reading", "Aronow & Miller (2019), cap. 2, §§2.1–2.2.2", 48, 584, 720, 30, {
      fontSize: 20,
      color: C.muted,
    });
    addText(slide, "cover-number", "01", 1170, 682, 62, 20, {
      fontSize: 15,
      bold: true,
      alignment: "right",
      color: C.muted,
    });
    addNotes(
      slide,
      "Abra com a pergunta: como resumir uma distribuição complexa sem fingir que conhecemos todo o processo que gerou os dados? Explique que a aula constrói os objetos que aparecerão no lab e, mais tarde, na regressão.",
      [`Aronow e Miller (2019), cap. 2, pp. 44–66. ${DOI}`, `Syllabus atualizado: ${SYLLABUS}`],
    );
  }

  // 2. Objetivos — grade 2x2.
  {
    const slide = newSlide(presentation);
    addStandardFrame(slide, 2, "Ao final, você deve saber calcular — e interpretar");
    const cells = [
      [48, 184, "01", "Centro", "Explicar esperança como característica da distribuição, não como observação típica."],
      [656, 184, "02", "Dispersão", "Distinguir momento, variância, desvio-padrão, MSE e suas unidades."],
      [48, 408, "03", "Associação", "Interpretar covariância e correlação como resumos de co-movimento linear."],
      [656, 408, "04", "Limites", "Reconhecer por que correlação zero não significa independência nem causalidade."],
    ];
    for (const [left, top, idx, head, body] of cells) {
      addText(slide, `obj-${idx}`, idx, left, top, 60, 40, { fontSize: 22, bold: true, color: C.accentStrong });
      addText(slide, `obj-head-${idx}`, head, left + 76, top, 500, 42, { fontSize: 31, bold: true });
      addText(slide, `obj-body-${idx}`, body, left + 76, top + 52, 490, 92, { fontSize: 22, color: C.muted });
      addRule(slide, left, top + 164, 560, C.rule, 1);
    }
    addNotes(
      slide,
      "Apresente os quatro objetivos como uma sequência: primeiro descrevemos uma variável; depois duas; por fim aprendemos o que esses resumos não conseguem dizer.",
      [`Syllabus atualizado, objetivos e calendário da Aula 2: ${SYLLABUS}`, `Aronow e Miller (2019), cap. 2. ${CAMBRIDGE}`],
    );
  }

  // 3. Distribuição versus resumo versus amostra.
  {
    const slide = newSlide(presentation);
    addStandardFrame(slide, 3, "Um resumo não é a distribuição — nem a amostra");
    addBox(slide, "population-panel", 48, 190, 550, 390, C.panel2, "none");
    addBox(slide, "sample-panel", 682, 190, 550, 390, C.panel2, "none");
    addText(slide, "population-head", "Objeto populacional", 78, 220, 490, 44, { fontSize: 31, bold: true });
    addText(slide, "population-formula", "Fₓ  →  E[X], V[X], ρ[X,Y]", 78, 296, 490, 64, { fontSize: 35, bold: true, color: C.accentStrong });
    addText(slide, "population-body", "A distribuição pode ser complexa. Escolhemos características com significado substantivo, sem precisar supor uma família paramétrica.", 78, 392, 460, 132, { fontSize: 23, color: C.muted });
    addText(slide, "sample-head", "Objeto observado", 712, 220, 490, 44, { fontSize: 31, bold: true });
    addText(slide, "sample-formula", "x₁,…,xₙ  →  x̄, s², r", 712, 296, 490, 64, { fontSize: 35, bold: true, color: C.accentStrong });
    addText(slide, "sample-body", "Amostras fornecem estatísticas que, sob condições estudadas depois, ajudam a aprender sobre as características populacionais.", 712, 392, 460, 132, { fontSize: 23, color: C.muted });
    addText(slide, "sample-warning", "Hoje: definimos primeiro o alvo.", 48, 610, 1184, 34, { fontSize: 24, bold: true, alignment: "center" });
    addNotes(
      slide,
      "Este é o principal cuidado conceitual da aula. E[X] é um operador sobre a distribuição; x̄ é um número calculado nos dados. A relação entre ambos será tema de estimação no capítulo 3.",
      [`Aronow e Miller (2019), cap. 2, introdução e §2.1, pp. 44–45. ${DOI}`],
    );
  }

  // 4. Definição da esperança.
  {
    const slide = newSlide(presentation);
    addStandardFrame(slide, 4, "Esperança é uma média ponderada");
    addText(slide, "expect-intro", "O operador E[·] recebe uma variável aleatória; os pesos vêm da distribuição.", 48, 174, 1184, 42, { fontSize: 25, color: C.muted });
    addBox(slide, "discrete-panel", 48, 244, 560, 280, C.panel2, "none");
    addBox(slide, "continuous-panel", 672, 244, 560, 280, C.panel2, "none");
    addText(slide, "discrete-head", "X discreta", 78, 270, 500, 40, { fontSize: 30, bold: true });
    addText(slide, "discrete-eq", "E[X] = Σₓ x fₓ(x)", 78, 340, 500, 56, { fontSize: 39, bold: true, color: C.accentStrong });
    addText(slide, "discrete-note", "Cada valor é ponderado por sua probabilidade.", 78, 430, 470, 62, { fontSize: 23, color: C.muted });
    addText(slide, "continuous-head", "X contínua", 702, 270, 500, 40, { fontSize: 30, bold: true });
    addText(slide, "continuous-eq", "E[X] = ∫₋∞^∞ x fₓ(x) dx", 702, 340, 500, 56, { fontSize: 37, bold: true, color: C.accentStrong });
    addText(slide, "continuous-note", "fₓ(x) é densidade; a probabilidade é área.", 702, 430, 470, 62, { fontSize: 23, color: C.muted });
    addText(slide, "expect-units", "Unidades de E[X] = unidades de X", 48, 570, 1184, 42, { fontSize: 27, bold: true, alignment: "center" });
    addNotes(
      slide,
      "Detalhe o papel de fₓ: no caso discreto é massa de probabilidade; no contínuo é densidade. A condição técnica é convergência absoluta: Σ|x|fₓ(x)<∞ ou ∫|x|fₓ(x)dx<∞.",
      [`Aronow e Miller (2019), Definição 2.1.1, pp. 45–46. ${DOI}`],
    );
  }

  // 5. Exemplos da esperança e pergunta rápida.
  {
    const slide = newSlide(presentation);
    addStandardFrame(slide, 5, "A esperança pode não ocorrer");
    slide.charts.add("bar", {
      position: { left: 48, top: 180, width: 640, height: 408 },
      categories: ["1", "2", "3", "4", "5", "6"],
      series: [{ name: "Probabilidade", values: [1 / 6, 1 / 6, 1 / 6, 1 / 6, 1 / 6, 1 / 6], fill: C.accentStrong, valuesFormatCode: "0%" }],
      barOptions: { direction: "column", grouping: "clustered", gapWidth: 55 },
      hasLegend: false,
      dataLabels: { showValue: true, position: "outEnd", textStyle: { fill: C.ink, fontSize: 17, bold: true } },
      chartFill: C.canvas,
      chartLine: { style: "solid", fill: C.canvas, width: 0 },
      plotAreaFill: { type: "none" },
      plotAreaLine: { style: "solid", fill: C.canvas, width: 0 },
      xAxis: { visible: true, title: { text: "Resultado do dado", textStyle: { fill: C.muted, fontSize: 18 } }, textStyle: { fill: C.ink, fontSize: 18 }, line: { style: "solid", fill: C.rule, width: 1 }, majorGridlines: null },
      yAxis: { visible: true, min: 0, max: 0.22, majorUnit: 0.05, numberFormatCode: "0%", title: { text: "Probabilidade", textStyle: { fill: C.muted, fontSize: 18 } }, textStyle: { fill: C.muted, fontSize: 17 }, majorGridlines: { style: "solid", fill: C.panel, width: 1 }, line: { style: "solid", fill: C.canvas, width: 0 } },
    });
    addCaption(slide, 1, "Distribuição de um dado justo; a média é 3,5.", 48, 596, 640);
    addCallout(slide, "die-mean", "E[X] = 3,5", "Nenhuma face mostra 3,5 — o centro não precisa ser observável.", 740, 202, 442, 166, C.panel);
    addCallout(slide, "bernoulli", "E[D] = p", "Para um indicador D∈{0,1}, a esperança é Pr(D=1).", 740, 394, 442, 166, C.accentPale);
    addText(slide, "quick-q-5", "Pergunta rápida: se E[D]=0,63, o que significa 0,63?", 740, 590, 442, 48, { fontSize: 22, bold: true });
    addNotes(
      slide,
      "No dado justo, E[X]=7/2 embora Pr(X=3,5)=0. Para uma Bernoulli, E[D]=Pr(D=1). Peça à turma que traduza 0,63 como probabilidade ou proporção populacional, não como valor de uma pessoa.",
      [`Aronow e Miller (2019), Exemplos 2.1.2 e 2.1.3, p. 46. ${DOI}`],
    );
  }

  // 6. Funções e linearidade.
  {
    const slide = newSlide(presentation);
    addStandardFrame(slide, 6, "Linearidade não exige independência");
    addBox(slide, "lotus-panel", 48, 184, 544, 186, C.panel2, "none");
    addText(slide, "lotus-head", "Função de uma variável", 76, 208, 490, 40, { fontSize: 29, bold: true });
    addText(slide, "lotus-eq", "E[g(X)] = Σₓ g(x)fₓ(x)", 76, 278, 490, 48, { fontSize: 34, bold: true, color: C.accentStrong });
    addBox(slide, "linear-panel", 640, 184, 592, 186, C.accentPale, "none");
    addText(slide, "linear-head", "Combinação linear", 668, 208, 536, 40, { fontSize: 29, bold: true });
    addText(slide, "linear-eq", "E[aX+bY+c] = aE[X]+bE[Y]+c", 668, 278, 536, 52, { fontSize: 31, bold: true, color: C.ink });
    addText(slide, "linear-proof-head", "Por quê?", 48, 408, 120, 40, { fontSize: 29, bold: true });
    addText(slide, "linear-proof", "E[aX+bY+c]\n= E[aX] + E[bY] + E[c]\n= aE[X] + bE[Y] + c", 170, 400, 580, 170, { fontSize: 30, lineSpacing: 1.12 });
    addBox(slide, "linear-warning", 802, 408, 430, 166, C.panel, "none");
    addText(slide, "linear-warning-head", "Armadilha", 828, 432, 378, 36, { fontSize: 27, bold: true });
    addText(slide, "linear-warning-body", "E[XY]=E[X]E[Y] não vem da linearidade. Independência é uma condição suficiente — não necessária.", 828, 484, 360, 76, { fontSize: 21 });
    addNotes(
      slide,
      "Faça a derivação devagar. Constantes saem da esperança; somas se separam termo a termo. Em seguida, contraste combinação linear com produto. Não diga que E[XY]=E[X]E[Y] é equivalente a independência.",
      [`Aronow e Miller (2019), Teoremas 2.1.5, 2.1.6 e 2.1.9, pp. 47–50. ${DOI}`],
    );
  }

  // 7. Momentos.
  {
    const slide = newSlide(presentation);
    addStandardFrame(slide, 7, "Momentos organizam centro, dispersão e forma");
    const blocks = [
      [48, 184, "1º bruto", "μ′₁ = E[X]", "Centro da distribuição"],
      [656, 184, "1º central", "μ₁ = E[X−E[X]] = 0", "Sempre zero"],
      [48, 408, "j-ésimo bruto", "μ′ⱼ = E[Xʲ]", "Depende da localização"],
      [656, 408, "j-ésimo central", "μⱼ = E[(X−E[X])ʲ]", "Isola forma e dispersão"],
    ];
    let i = 0;
    for (const [left, top, label, eq, desc] of blocks) {
      i += 1;
      addText(slide, `moment-label-${i}`, label, left, top, 560, 34, { fontSize: 19, bold: true, color: C.accentStrong });
      addText(slide, `moment-eq-${i}`, eq, left, top + 52, 560, 48, { fontSize: 32, bold: true });
      addText(slide, `moment-desc-${i}`, desc, left, top + 116, 560, 34, { fontSize: 22, color: C.muted });
      addRule(slide, left, top + 168, 560, C.rule, 1);
    }
    addText(slide, "moment-takeaway", "O segundo momento central é a variância:  μ₂ = V[X]", 48, 612, 1184, 38, { fontSize: 27, bold: true, alignment: "center" });
    addNotes(
      slide,
      "Mostre que a média é o primeiro momento bruto, não o primeiro central. Se Y=X+c, a forma não muda, mas momentos brutos geralmente mudam. Um momento de ordem j tem unidades elevadas à potência j.",
      [`Aronow e Miller (2019), Definições 2.1.10 e 2.1.11, pp. 50–52. ${DOI}`],
    );
  }

  // 8. Identidade da variância.
  {
    const slide = newSlide(presentation);
    addStandardFrame(slide, 8, "E[X] é constante na variância");
    addText(slide, "var-definition", "V[X] = E[(X − E[X])²]", 48, 176, 1184, 58, { fontSize: 40, bold: true, alignment: "center", color: C.accentStrong });
    const steps = [
      [48, "1", "Expanda", "E[X² − 2XE[X] + E[X]²]"],
      [440, "2", "Use linearidade", "E[X²] − 2E[X]E[X] + E[X]²"],
      [832, "3", "Simplifique", "E[X²] − E[X]²"],
    ];
    for (const [left, idx, label, eq] of steps) {
      addText(slide, `var-step-num-${idx}`, idx, left, 292, 48, 48, { fontSize: 24, bold: true, color: C.accentStrong, alignment: "center" });
      addText(slide, `var-step-label-${idx}`, label, left + 66, 292, 270, 38, { fontSize: 25, bold: true });
      addText(slide, `var-step-eq-${idx}`, eq, left, 366, 352, 104, { fontSize: 22, bold: true, color: C.muted, alignment: "center", verticalAlignment: "middle" });
      if (idx !== "3") addBox(slide, `var-arrow-${idx}`, left + 354, 405, 28, 4, C.accentStrong, "none");
    }
    addBox(slide, "var-result-panel", 236, 520, 808, 92, C.accentPale, "none");
    addText(slide, "var-result", "V[X] = E[X²] − E[X]²", 236, 538, 808, 56, { fontSize: 39, bold: true, alignment: "center" });
    addText(slide, "var-warning", "Não confunda E[X²] com E[X]².", 48, 624, 1184, 30, { fontSize: 22, bold: true, alignment: "center", color: C.muted });
    addNotes(
      slide,
      "Abra a identidade linha por linha. O passo crucial é tratar E[X] como constante ao aplicar outra esperança. Reforce a diferença entre média dos quadrados e quadrado da média.",
      [`Aronow e Miller (2019), Definição 2.1.12 e Teorema 2.1.13, p. 52. ${DOI}`],
    );
  }

  // 9. Unidades e escala.
  {
    const slide = newSlide(presentation);
    addStandardFrame(slide, 9, "Desvio-padrão retorna à escala original");
    addText(slide, "units-caption", "Tabela 1. Como cada medida responde às unidades e à transformação Z=aX+c", 48, 170, 1184, 30, { fontSize: 19, italic: true, color: C.muted });
    const cols = [48, 360, 690, 980, 1232];
    const rows = [214, 284, 354, 424, 494, 564];
    const headers = ["Medida", "Unidades", "Somar c", "Multiplicar por a"];
    for (let j = 0; j < headers.length; j += 1) {
      addBox(slide, `unit-head-bg-${j}`, cols[j], rows[0], cols[j + 1] - cols[j], 54, C.ink, "none");
      addText(slide, `unit-head-${j}`, headers[j], cols[j] + 14, rows[0] + 14, cols[j + 1] - cols[j] - 28, 28, { fontSize: 20, bold: true, color: C.canvas });
    }
    const data = [
      ["E[X]", "u", "+ c", "× a"],
      ["V[X]", "u²", "sem mudança", "× a²"],
      ["σ[X]", "u", "sem mudança", "× |a|"],
      ["MSE", "u²", "depende do alvo", "× a²*"],
      ["RMSE", "u", "depende do alvo", "× |a|*"],
    ];
    for (let i = 0; i < data.length; i += 1) {
      const top = rows[i + 1];
      const fill = i % 2 === 0 ? C.panel2 : C.canvas;
      for (let j = 0; j < 4; j += 1) {
        addBox(slide, `unit-cell-${i}-${j}`, cols[j], top, cols[j + 1] - cols[j], 54, fill, C.rule);
        addText(slide, `unit-text-${i}-${j}`, data[i][j], cols[j] + 14, top + 14, cols[j + 1] - cols[j] - 28, 28, { fontSize: 20, bold: j === 0 });
      }
    }
    addText(slide, "units-footnote", "* Quando o alvo é transformado na mesma escala.", 48, 630, 1184, 26, { fontSize: 17, color: C.muted });
    addNotes(
      slide,
      "Use um exemplo em reais e milhares de reais. A variância muda por um fator de um milhão ao trocar reais por milhares? Não: se dividimos por mil, ela divide por um milhão. O desvio-padrão divide por mil e permanece interpretável na nova unidade.",
      [`Aronow e Miller (2019), Teoremas 2.1.14 e 2.1.16 e Exemplo 2.1.17, pp. 52–54. ${DOI}`],
    );
  }

  // 10. Chebyshev versus normal.
  {
    const slide = newSlide(presentation);
    addStandardFrame(slide, 10, "Dois números não contam tudo");
    addBox(slide, "cheb-panel", 48, 184, 552, 402, C.panel2, "none");
    addBox(slide, "normal-panel", 632, 184, 600, 402, C.accentPale, "none");
    addText(slide, "cheb-head", "Sem supor a forma", 78, 214, 492, 40, { fontSize: 30, bold: true });
    addText(slide, "cheb-eq", "Pr(|X−E[X]| ≥ εσ[X]) ≤ 1/ε²", 78, 294, 492, 58, { fontSize: 31, bold: true, color: C.accentStrong, alignment: "center" });
    addText(slide, "cheb-two", "ε=2  →  ao menos 75% dentro de 2σ", 78, 394, 492, 36, { fontSize: 23, bold: true });
    addText(slide, "cheb-three", "ε=3  →  ao menos 88,9% dentro de 3σ", 78, 454, 492, 36, { fontSize: 23, bold: true });
    addText(slide, "normal-head", "Se X é normal", 662, 214, 540, 40, { fontSize: 30, bold: true });
    addText(slide, "normal-eq", "X ~ N(μ, σ²)", 662, 294, 540, 58, { fontSize: 39, bold: true, alignment: "center" });
    addText(slide, "normal-properties", "E[X]=μ\nV[X]=σ²\nσ[X]=σ", 662, 382, 540, 134, { fontSize: 29, bold: true, alignment: "center", lineSpacing: 1.15 });
    addText(slide, "normal-warning", "N(2,9) tem desvio-padrão 3 — não 9.", 48, 616, 1184, 34, { fontSize: 23, bold: true, alignment: "center" });
    addNotes(
      slide,
      "Chebyshev é agnóstica: fornece limites gerais, não uma descrição exata. A regra 68–95–99,7 depende da normalidade. Para uma normal, média e desvio-padrão determinam toda a distribuição.",
      [`Aronow e Miller (2019), Teorema 2.1.18, Definição 2.1.19 e Teorema 2.1.20, pp. 54–56. ${DOI}`],
    );
  }

  // 11. MSE e RMSE.
  {
    const slide = newSlide(presentation);
    addStandardFrame(slide, 11, "MSE mede distância quadrática a um alvo");
    addText(slide, "mse-intro", "Queremos avaliar quão bem uma variável aleatória X aproxima um valor fixo c.", 48, 174, 1184, 38, { fontSize: 24, color: C.muted });
    addBox(slide, "mse-panel", 48, 244, 560, 258, C.panel2, "none");
    addText(slide, "mse-head", "Erro quadrático médio", 78, 272, 500, 42, { fontSize: 29, bold: true });
    addText(slide, "mse-eq", "MSE sobre c = E[(X−c)²]", 78, 352, 500, 56, { fontSize: 33, bold: true, color: C.accentStrong, alignment: "center" });
    addText(slide, "mse-units", "Unidades: u²", 78, 444, 500, 34, { fontSize: 23, bold: true, alignment: "center" });
    addBox(slide, "rmse-panel", 672, 244, 560, 258, C.accentPale, "none");
    addText(slide, "rmse-head", "Raiz do erro quadrático médio", 702, 272, 500, 42, { fontSize: 29, bold: true });
    addText(slide, "rmse-eq", "RMSE sobre c = √E[(X−c)²]", 702, 352, 500, 56, { fontSize: 31, bold: true, alignment: "center" });
    addText(slide, "rmse-units", "Unidades: u", 702, 444, 500, 34, { fontSize: 23, bold: true, alignment: "center" });
    addText(slide, "mse-relations", "MSE sobre 0 = E[X²]    ·    MSE sobre E[X] = V[X]", 48, 558, 1184, 46, { fontSize: 28, bold: true, alignment: "center" });
    addNotes(
      slide,
      "Explique por que o quadrado penaliza erros grandes. MSE e variância são parentes: escolher c=E[X] transforma o MSE na variância. RMSE apenas devolve a medida à escala original.",
      [`Aronow e Miller (2019), Definição 2.1.22, pp. 56–57. ${DOI}`],
    );
  }

  // 12. Decomposição do MSE.
  {
    const slide = newSlide(presentation);
    addStandardFrame(slide, 12, "MSE = flutuação + deslocamento");
    addBox(slide, "mse-decomp", 110, 176, 1060, 86, C.accentPale, "none");
    addText(slide, "mse-decomp-eq", "E[(X−c)²] = V[X] + (E[X]−c)²", 110, 198, 1060, 50, { fontSize: 39, bold: true, alignment: "center" });
    addBox(slide, "variance-component", 48, 322, 552, 246, C.panel2, "none");
    addText(slide, "variance-component-head", "V[X]", 78, 350, 492, 50, { fontSize: 40, bold: true, color: C.accentStrong, alignment: "center" });
    addText(slide, "variance-component-label", "Flutuação", 78, 420, 492, 38, { fontSize: 28, bold: true, alignment: "center" });
    addText(slide, "variance-component-body", "Quanto X varia ao redor da própria esperança.", 92, 480, 464, 58, { fontSize: 22, alignment: "center", color: C.muted });
    addBox(slide, "bias-component", 632, 322, 600, 246, C.panel2, "none");
    addText(slide, "bias-component-head", "(E[X]−c)²", 662, 350, 540, 50, { fontSize: 40, bold: true, color: C.accentStrong, alignment: "center" });
    addText(slide, "bias-component-label", "Deslocamento", 662, 420, 540, 38, { fontSize: 28, bold: true, alignment: "center" });
    addText(slide, "bias-component-body", "Distância sistemática entre a esperança e o alvo.", 682, 480, 500, 58, { fontSize: 22, alignment: "center", color: C.muted });
    addText(slide, "bias-nuance", "É a estrutura da decomposição viés–variância; o vocabulário formal de estimação vem no cap. 3.", 48, 610, 1184, 34, { fontSize: 21, bold: true, alignment: "center" });
    addNotes(
      slide,
      "Derive escrevendo X−c=(X−E[X])+(E[X]−c). Ao elevar ao quadrado, o termo cruzado some porque E[X−E[X]]=0. O livro apresenta a decomposição aqui, mas reserva o contexto formal de viés de estimadores para o capítulo 3.",
      [`Aronow e Miller (2019), Teorema 2.1.23, p. 57. ${DOI}`],
    );
  }

  // 13. Esperança minimiza MSE.
  {
    const slide = newSlide(presentation);
    addStandardFrame(slide, 13, "A melhor previsão constante é E[X]");
    const cs = Array.from({ length: 41 }, (_, i) => -0.5 + i * 0.05);
    const mse = cs.map((c) => c * c - c + 0.5);
    slide.charts.add("scatter", {
      position: { left: 48, top: 174, width: 700, height: 418 },
      series: [
        { name: "MSE(c)", xValues: cs, values: mse, line: { style: "solid", fill: C.accentStrong, width: 3 }, marker: { symbol: "none" } },
        { name: "Mínimo", xValues: [0.5], values: [0.25], line: { style: "solid", fill: C.warning, width: 0 }, marker: { symbol: "circle", size: 9 }, fill: C.warning },
      ],
      scatterOptions: { style: "smoothWithMarkers", varyColors: false },
      hasLegend: true,
      legend: { position: "bottom", overlay: false, textStyle: { fill: C.muted, fontSize: 16 } },
      chartFill: C.canvas,
      chartLine: { style: "solid", fill: C.canvas, width: 0 },
      plotAreaFill: { type: "none" },
      plotAreaLine: { style: "solid", fill: C.canvas, width: 0 },
      xAxis: { visible: true, min: -0.5, max: 1.5, majorUnit: 0.5, numberFormatCode: "0.00", title: { text: "Escolha de c", textStyle: { fill: C.muted, fontSize: 18 } }, textStyle: { fill: C.muted, fontSize: 17 }, line: { style: "solid", fill: C.rule, width: 1 }, majorGridlines: null },
      yAxis: { visible: true, min: 0, max: 1.4, majorUnit: 0.25, numberFormatCode: "0.00", title: { text: "MSE", textStyle: { fill: C.muted, fontSize: 18 } }, textStyle: { fill: C.muted, fontSize: 17 }, majorGridlines: { style: "solid", fill: C.panel, width: 1 }, line: { style: "solid", fill: C.canvas, width: 0 } },
    });
    addCaption(slide, 2, "MSE de uma moeda justa em função da previsão c.", 48, 600, 700);
    addText(slide, "mse-min-eq", "arg min em c\nE[(X−c)²] = E[X]", 792, 206, 390, 88, { fontSize: 32, bold: true, alignment: "center", color: C.accentStrong });
    addCallout(slide, "coin-min", "c* = 0,5", "Para X~Bernoulli(0,5), o MSE mínimo é 0,25.", 790, 332, 396, 162, C.panel);
    addText(slide, "quick-q-13", "Pergunta rápida: por que 0,5 é melhor que prever sempre 0 ou 1?", 790, 532, 396, 76, { fontSize: 22, bold: true });
    addNotes(
      slide,
      "Use a decomposição anterior: V[X] não depende de c, então basta minimizar (E[X]−c)². Para a moeda justa, MSE(c)=c²−c+1/2 e o mínimo ocorre em 1/2.",
      [`Aronow e Miller (2019), Teorema 2.1.24 e Exemplo 2.1.25, pp. 58–59. ${DOI}`],
    );
  }

  // 14. Covariância.
  {
    const slide = newSlide(presentation);
    addStandardFrame(slide, 14, "Covariância e co-movimento");
    addBox(slide, "cov-def-panel", 48, 184, 584, 190, C.accentPale, "none");
    addText(slide, "cov-def", "Cov[X,Y] = E[(X−E[X])(Y−E[Y])]", 76, 230, 528, 78, { fontSize: 31, bold: true, alignment: "center" });
    addBox(slide, "cov-alt-panel", 664, 184, 568, 190, C.panel2, "none");
    addText(slide, "cov-alt", "Cov[X,Y] = E[XY] − E[X]E[Y]", 692, 230, 512, 78, { fontSize: 31, bold: true, alignment: "center" });
    addText(slide, "cov-positive", "+", 72, 432, 62, 54, { fontSize: 42, bold: true, color: C.accentStrong, alignment: "center" });
    addText(slide, "cov-positive-body", "X acima da média tende a vir com Y acima da média.", 154, 424, 420, 84, { fontSize: 23 });
    addText(slide, "cov-negative", "−", 662, 432, 62, 54, { fontSize: 42, bold: true, color: C.accentStrong, alignment: "center" });
    addText(slide, "cov-negative-body", "X acima da média tende a vir com Y abaixo da média.", 744, 424, 438, 84, { fontSize: 23 });
    addRule(slide, 48, 540, 1184, C.rule, 1);
    addText(slide, "cov-units", "Unidades de Cov[X,Y] = unidades de X × unidades de Y", 48, 570, 1184, 38, { fontSize: 26, bold: true, alignment: "center" });
    addText(slide, "cov-caution", "Magnitude depende da escala — não compare covariâncias medidas em unidades diferentes.", 48, 618, 1184, 32, { fontSize: 21, alignment: "center", color: C.muted });
    addNotes(
      slide,
      "Faça a interpretação pelos sinais dos desvios, não por valores brutos altos e baixos. A covariância é constante, não variável aleatória. Mostre que Cov[X,X]=V[X].",
      [`Aronow e Miller (2019), Definição 2.2.1 e Teorema 2.2.2, pp. 59–60. ${DOI}`],
    );
  }

  // 15. Variância de somas e propriedades.
  {
    const slide = newSlide(presentation);
    addStandardFrame(slide, 15, "A variância de uma soma inclui o co-movimento");
    addBox(slide, "varsum-main", 100, 178, 1080, 92, C.accentPale, "none");
    addText(slide, "varsum-main-eq", "V[X+Y] = V[X] + 2Cov[X,Y] + V[Y]", 100, 200, 1080, 52, { fontSize: 38, bold: true, alignment: "center" });
    const props = [
      [48, 330, "Simetria", "Cov[X,Y] = Cov[Y,X]"],
      [656, 330, "Caso especial", "Cov[X,X] = V[X]"],
      [48, 482, "Mudança de escala", "Cov[aX+c,bY+d] = abCov[X,Y]"],
      [656, 482, "Se Cov=0", "V[X+Y] = V[X]+V[Y]"],
    ];
    let i = 0;
    for (const [left, top, head, eq] of props) {
      i += 1;
      addText(slide, `covprop-head-${i}`, head, left, top, 560, 32, { fontSize: 20, bold: true, color: C.accentStrong });
      addText(slide, `covprop-eq-${i}`, eq, left, top + 48, 560, 54, { fontSize: 27, bold: true });
      addRule(slide, left, top + 118, 560, C.rule, 1);
    }
    addText(slide, "varsum-warning", "Erro comum: V[X+Y]=V[X]+V[Y] só quando Cov[X,Y]=0.", 48, 622, 1184, 32, { fontSize: 22, bold: true, alignment: "center" });
    addNotes(
      slide,
      "Ligue a fórmula a (x+y)²=x²+2xy+y². Variância não é linear. Independência implica Cov=0, mas Cov=0 também pode ocorrer sem independência.",
      [`Aronow e Miller (2019), Teoremas 2.2.3 e 2.2.4, pp. 60–62. ${DOI}`],
    );
  }

  // 16. Correlação.
  {
    const slide = newSlide(presentation);
    addStandardFrame(slide, 16, "Correlação mede associação linear sem unidades");
    addText(slide, "corr-main", "ρ[X,Y] = Cov[X,Y] / (σ[X]σ[Y])", 48, 176, 1184, 62, { fontSize: 40, bold: true, alignment: "center", color: C.accentStrong });
    addBox(slide, "corr-range", 48, 282, 352, 240, C.panel2, "none");
    addText(slide, "corr-range-head", "Escala", 72, 306, 304, 38, { fontSize: 27, bold: true });
    addText(slide, "corr-range-eq", "−1 ≤ ρ ≤ 1", 72, 376, 304, 52, { fontSize: 36, bold: true, alignment: "center" });
    addText(slide, "corr-range-body", "Sem unidade e com sinal igual ao da covariância.", 72, 456, 304, 48, { fontSize: 20, color: C.muted, alignment: "center" });
    addBox(slide, "corr-transform", 440, 282, 392, 240, C.accentPale, "none");
    addText(slide, "corr-transform-head", "Mudança de escala", 464, 306, 344, 38, { fontSize: 27, bold: true });
    addText(slide, "corr-transform-eq", "ρ[aX+c,bY+d]\n= sgn(ab)ρ[X,Y]", 464, 370, 344, 88, { fontSize: 28, bold: true, alignment: "center" });
    addText(slide, "corr-transform-body", "Unidades positivas não mudam |ρ|.", 464, 472, 344, 30, { fontSize: 20, color: C.muted, alignment: "center" });
    addBox(slide, "corr-limit", 872, 282, 360, 240, C.panel2, "none");
    addText(slide, "corr-limit-head", "Limite", 896, 306, 312, 38, { fontSize: 27, bold: true });
    addText(slide, "corr-limit-eq", "ρ=0", 896, 376, 312, 52, { fontSize: 38, bold: true, alignment: "center" });
    addText(slide, "corr-limit-body", "Sem co-movimento linear médio — não sem relação.", 896, 456, 312, 48, { fontSize: 20, color: C.muted, alignment: "center" });
    addText(slide, "corr-errors", "Correlação não é causalidade · Correlação é indefinida se σ[X]=0 ou σ[Y]=0", 48, 578, 1184, 54, { fontSize: 23, bold: true, alignment: "center" });
    addNotes(
      slide,
      "A padronização elimina unidades. Somar constantes não muda a correlação; multiplicar uma variável por número negativo inverte o sinal. Reforce que correlação resume apenas associação linear.",
      [`Aronow e Miller (2019), Definição 2.2.5 e Teoremas 2.2.6 e 2.2.7, pp. 62–64. ${DOI}`],
    );
  }

  // 17. Independência e contraexemplo.
  {
    const slide = newSlide(presentation);
    addStandardFrame(slide, 17, "Independência implica correlação zero");
    addText(slide, "ind-chain", "X ⟂ Y  ⇒  E[XY]=E[X]E[Y]  ⇒  Cov[X,Y]=0  ⇒  ρ[X,Y]=0", 48, 174, 1184, 52, { fontSize: 30, bold: true, alignment: "center", color: C.accentStrong });
    addText(slide, "ind-converse", "Mas ρ[X,Y]=0 ⇏ X ⟂ Y", 724, 222, 458, 34, { fontSize: 23, bold: true, alignment: "center" });
    slide.charts.add("scatter", {
      position: { left: 48, top: 252, width: 620, height: 342 },
      series: [{ name: "Y=X²", xValues: [-1, 0, 1], values: [1, 0, 1], line: { style: "solid", fill: C.accentStrong, width: 0 }, marker: { symbol: "circle", size: 10 }, fill: C.accentStrong }],
      scatterOptions: { style: "marker", varyColors: false },
      hasLegend: false,
      chartFill: C.canvas,
      chartLine: { style: "solid", fill: C.canvas, width: 0 },
      plotAreaFill: { type: "none" },
      plotAreaLine: { style: "solid", fill: C.canvas, width: 0 },
      xAxis: { visible: true, min: -1, max: 1, majorUnit: 0.5, numberFormatCode: "0.00", title: { text: "X", textStyle: { fill: C.muted, fontSize: 18 } }, textStyle: { fill: C.muted, fontSize: 17 }, line: { style: "solid", fill: C.rule, width: 1 }, majorGridlines: null },
      yAxis: { visible: true, min: -0.1, max: 1.2, majorUnit: 0.25, numberFormatCode: "0.00", title: { text: "Y=X²", textStyle: { fill: C.muted, fontSize: 18 } }, textStyle: { fill: C.muted, fontSize: 17 }, majorGridlines: { style: "solid", fill: C.panel, width: 1 }, line: { style: "solid", fill: C.canvas, width: 0 } },
    });
    addCaption(slide, 3, "Dependência determinística não linear com correlação zero.", 48, 600, 620);
    addCallout(slide, "ind-corr", "ρ[X,Y] = 0", "Com X uniforme em {−1,0,1} e Y=X², E[XY]=0.", 724, 280, 458, 154, C.panel);
    addCallout(slide, "ind-dep", "Y depende de X", "Conhecer X determina Y exatamente. Logo, X e Y não são independentes.", 724, 466, 458, 154, C.accentPale);
    addNotes(
      slide,
      "Calcule com a turma: E[X]=0, E[Y]=2/3 e E[XY]=E[X³]=0. Portanto Cov=0, mas Y é função determinística de X. A exceção importante é a normal bivariada, em que correlação zero implica independência.",
      [`Aronow e Miller (2019), Teorema 2.2.8 e Exemplo 2.2.9, pp. 64–66. ${DOI}`],
    );
  }

  // 18. Ponte para o lab — sem desenvolver o lab.
  {
    const slide = newSlide(presentation);
    addStandardFrame(slide, 18, "A teoria organiza a pergunta do lab", "PONTE PARA O LAB · FLUXO DESCRITIVO E ASSOCIACIONAL");
    addText(slide, "lab-bridge-intro", "Os resumos de hoje estruturam a sequência das comparações substantivas.", 48, 172, 1184, 40, { fontSize: 25, color: C.muted });
    const flow = [
      [48, "01", "Descrever", "Brasil antes e depois do marco temporal ainda a confirmar."],
      [340, "02", "Associar", "Fluxo comercial com a China e alinhamento de voto."],
      [632, "03", "Comparar", "Brasil frente a um donor pool de países comparáveis."],
      [924, "04", "Estender", "Painel com indicador China=principal destino, em etapa posterior."],
    ];
    for (const [left, idx, head, body] of flow) {
      addText(slide, `bridge-idx-${idx}`, idx, left, 270, 70, 44, { fontSize: 22, bold: true, color: C.accentStrong });
      addText(slide, `bridge-head-${idx}`, head, left, 332, 260, 42, { fontSize: 29, bold: true });
      addText(slide, `bridge-body-${idx}`, body, left, 398, 250, 132, { fontSize: 21, color: C.muted });
      if (idx !== "04") addBox(slide, `bridge-arrow-${idx}`, left + 244, 290, 32, 4, C.rule, "none");
    }
    addBox(slide, "bridge-final", 196, 570, 888, 72, C.accentPale, "none");
    addText(slide, "bridge-final-text", "Pergunta-guia: qual resumo descreve o padrão — e o que ele não autoriza concluir?", 196, 590, 888, 36, { fontSize: 25, bold: true, alignment: "center" });
    addNotes(
      slide,
      "Não fixe o ano do corte: ele ainda está sob confirmação. Mantenha o enquadramento descritivo/associacional e mostre apenas como esperança, variância e correlação organizam a leitura dos padrões. Encerre preparando a transição para o material de lab separado.",
      [`Syllabus atualizado, formato e projeto aplicado cumulativo: ${SYLLABUS}`, `Aronow e Miller (2019), cap. 2, síntese conceitual. ${CAMBRIDGE}`],
    );
  }

  for (const [index, slide] of presentation.slides.items.entries()) {
    const stem = `slide-${String(index + 1).padStart(2, "0")}`;
    const png = await presentation.export({ slide, format: "png", scale: 1 });
    await writeBlob(path.join(PREVIEW_DIR, `${stem}.png`), png);
    const layout = await slide.export({ format: "layout" });
    await fs.writeFile(path.join(PREVIEW_DIR, `${stem}.layout.json`), await layout.text());
  }

  const montage = await presentation.export({ format: "webp", montage: true, scale: 1 });
  await writeBlob(MONTAGE_PATH, montage);

  const inspect = await presentation.inspect({
    kind: "slide,textbox,shape,chart,notes",
    maxChars: 60000,
  });
  await fs.writeFile(path.join(PREVIEW_DIR, "inspect.ndjson"), inspect.ndjson);

  const pptx = await PresentationFile.exportPptx(presentation);
  await pptx.save(PPTX_PATH);

  console.log(JSON.stringify({ slides: presentation.slides.items.length, pptx: PPTX_PATH, montage: MONTAGE_PATH }, null, 2));
}

buildDeck().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
