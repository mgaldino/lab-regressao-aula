# Aula 7: regressão e previsão eleitoral por zona

1. Extraia a pasta inteira e abra lab-regressao-aula-2026.Rproj no RStudio.
2. Se necessário, instale os pacotes: install.packages(c("dplyr", "ggplot2", "here", "scales")).
3. Abra projeto_agna/scripts/18_laboratorio_aula7_previsao_eleitoral.R e execute por blocos.
4. Registre as respostas às seis perguntas e a interpretação final. Duração prevista: 75 minutos.

Os dois CSVs já contêm os dados públicos do TSE preparados por UF/Exterior + zona. Não é necessário baixar arquivos em sala. Há 2.637 zonas em 2022 e 2.641 em 2026, incluindo uma zona agregada do Exterior (ZZ) em cada ano. A porcentagem tem como denominador todos os votos válidos do respectivo turno. O ajuste usa Lula nos dois turnos de 2022, disputados contra Jair Bolsonaro. A aplicação prevê Lula versus Flávio Bolsonaro no segundo turno de 2026.

O modelo com categorias geográficas estima a porcentagem de Lula. A do adversário é seu complemento para 100. A agregação nacional usa votos válidos de 2026 T1 como pesos e depende da estabilidade desses pesos relativos entre turnos. Aplicar o modelo a outro ano também depende da estabilidade da relação entre turnos. O bootstrap é um exercício de sensibilidade do ajuste à reamostragem e não inclui toda a incerteza futura; ZZ, com uma linha, permanece fixa.

O script exporta resultados e dois gráficos PDF em projeto_agna/output/aula_07/laboratorio_eleitoral/. O script 14 é uma atividade complementar de Monte Carlo com dados sintéticos e não integra os 75 minutos da atividade eleitoral.

Proveniência e variáveis: veja o diretório projeto_agna/data/eleicoes_2022_2026/docs. O pacote discente tem somente os CSVs preparados. Os snapshots e os scripts de coleta, preparação e validação docente permanecem no repositório do curso.
